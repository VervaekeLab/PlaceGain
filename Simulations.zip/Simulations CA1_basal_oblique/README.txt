Files to simulate on realization of a hippocampal CA1 neuron (see modeldb https://modeldb.science/55035, CA1 pyramidal neuron: signal propagation in oblique dendrites (Migliore et al 2005)) with 100 excitatory AMPA synapses randomly distributed in the basal/oblique region (<400um) with Poisson-firing statistics with rate/synapse = 5/s, gbar=0.5nS, t_rise=1ms, t_decay=11ms, Erev=0mV. 
The synapses are activated with random on and offset drawn from Gaussians, mean onset was 5000ms, mean offset 6000ms, with std=500ms. If the offset was smaller than the onset for a synapse, times were exchanged.
Additionally, 50 Poisson-firing GABA synapses were randomly distributed over the apical tree (>430um) at 1/s, Erev=-70mV,  t_rise=0.13ms, t_decay=11ms. Total sim-duration=10sec, timestep dt=0.1ms. 
All other parameters as in https://modeldb.science/55035.

For different realizations, the synapses were randomly redistributed.
The rate of the AMPA synapses was varied in {5,10,15,20,25,30,35,40}.
The rate of the GABA synapses was varied in {1,50,80}.



For results shown in Figure 5, the code was executed with neuron7.4.
Run with
<path to neuron dir/.../bin/>nrnivmodl
<path to neuron dir/.../bin/>nrniv -nogui -NFRAME 3000 LEMS_Sim_CA1mine1150erev70_nrn.py



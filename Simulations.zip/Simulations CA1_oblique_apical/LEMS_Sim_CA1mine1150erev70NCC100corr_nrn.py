'''
Neuron simulator export for:

Components:
    null (Type: notes)
    hd (Type: ionChannelHH:  conductance=1.0E-11 (SI conductance))
    null (Type: notes)
    hd__vhalflmin73 (Type: ionChannelHH:  conductance=1.0E-11 (SI conductance))
    null (Type: notes)
    hdmin73 (Type: ionChannelHH:  conductance=1.0E-11 (SI conductance))
    null (Type: notes)
    kad (Type: ionChannelHH:  conductance=1.0E-11 (SI conductance))
    null (Type: notes)
    kap (Type: ionChannelHH:  conductance=1.0E-11 (SI conductance))
    null (Type: notes)
    kdr (Type: ionChannelHH:  conductance=1.0E-11 (SI conductance))
    null (Type: notes)
    na3__ar1 (Type: ionChannelHH:  conductance=1.0E-11 (SI conductance))
    null (Type: notes)
    nax (Type: ionChannelHH:  conductance=1.0E-11 (SI conductance))
    null (Type: notes)
    pas (Type: ionChannelPassive:  conductance=1.0E-11 (SI conductance))
    CA1_mine (Type: cell)
    expTwoSynapseActE0 (Type: expTwoSynapseActE0:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.284 (SI time) duration=0.772 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE1 (Type: expTwoSynapseActE1:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.079 (SI time) duration=0.653 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE2 (Type: expTwoSynapseActE2:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.679 (SI time) duration=0.749 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE3 (Type: expTwoSynapseActE3:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.088 (SI time) duration=1.367 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE4 (Type: expTwoSynapseActE4:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.077 (SI time) duration=1.417 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE5 (Type: expTwoSynapseActE5:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.71 (SI time) duration=1.079 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE6 (Type: expTwoSynapseActE6:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.543 (SI time) duration=0.28 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE7 (Type: expTwoSynapseActE7:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.8580000000000005 (SI time) duration=0.398 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE8 (Type: expTwoSynapseActE8:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.222 (SI time) duration=0.254 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE9 (Type: expTwoSynapseActE9:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.317 (SI time) duration=0.854 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE10 (Type: expTwoSynapseActE10:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.655 (SI time) duration=1.086 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE11 (Type: expTwoSynapseActE11:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.48 (SI time) duration=0.157 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE12 (Type: expTwoSynapseActE12:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.6450000000000005 (SI time) duration=0.623 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE13 (Type: expTwoSynapseActE13:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.793 (SI time) duration=0.9540000000000001 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE14 (Type: expTwoSynapseActE14:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.162 (SI time) duration=2.257 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE15 (Type: expTwoSynapseActE15:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=3.974 (SI time) duration=1.828 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE16 (Type: expTwoSynapseActE16:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.84 (SI time) duration=1.536 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE17 (Type: expTwoSynapseActE17:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.795 (SI time) duration=0.127 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE18 (Type: expTwoSynapseActE18:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.368 (SI time) duration=1.609 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE19 (Type: expTwoSynapseActE19:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.766 (SI time) duration=1.102 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE20 (Type: expTwoSynapseActE20:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.42 (SI time) duration=0.6880000000000001 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE21 (Type: expTwoSynapseActE21:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.136 (SI time) duration=0.587 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE22 (Type: expTwoSynapseActE22:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.465 (SI time) duration=1.489 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE23 (Type: expTwoSynapseActE23:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.142 (SI time) duration=0.761 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE24 (Type: expTwoSynapseActE24:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.539 (SI time) duration=0.466 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE25 (Type: expTwoSynapseActE25:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.0920000000000005 (SI time) duration=0.77 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE26 (Type: expTwoSynapseActE26:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.418 (SI time) duration=0.312 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE27 (Type: expTwoSynapseActE27:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.376 (SI time) duration=0.34 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE28 (Type: expTwoSynapseActE28:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.626 (SI time) duration=1.387 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE29 (Type: expTwoSynapseActE29:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.7940000000000005 (SI time) duration=1.234 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE30 (Type: expTwoSynapseActE30:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=6.003 (SI time) duration=0.8270000000000001 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE31 (Type: expTwoSynapseActE31:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.053 (SI time) duration=0.631 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE32 (Type: expTwoSynapseActE32:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.495 (SI time) duration=0.04 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE33 (Type: expTwoSynapseActE33:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.806 (SI time) duration=0.735 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE34 (Type: expTwoSynapseActE34:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.8950000000000005 (SI time) duration=0.884 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE35 (Type: expTwoSynapseActE35:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.537 (SI time) duration=0.5730000000000001 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE36 (Type: expTwoSynapseActE36:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.406 (SI time) duration=1.774 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE37 (Type: expTwoSynapseActE37:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.833 (SI time) duration=0.889 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE38 (Type: expTwoSynapseActE38:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.808 (SI time) duration=1.004 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE39 (Type: expTwoSynapseActE39:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.059 (SI time) duration=0.642 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE40 (Type: expTwoSynapseActE40:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.107 (SI time) duration=1.286 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE41 (Type: expTwoSynapseActE41:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.027 (SI time) duration=1.465 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE42 (Type: expTwoSynapseActE42:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.508 (SI time) duration=1.135 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE43 (Type: expTwoSynapseActE43:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.76 (SI time) duration=1.482 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE44 (Type: expTwoSynapseActE44:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.815 (SI time) duration=0.388 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE45 (Type: expTwoSynapseActE45:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=3.9 (SI time) duration=2.069 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE46 (Type: expTwoSynapseActE46:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.644 (SI time) duration=1.1520000000000001 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE47 (Type: expTwoSynapseActE47:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.273 (SI time) duration=0.621 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE48 (Type: expTwoSynapseActE48:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.123 (SI time) duration=2.365 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE49 (Type: expTwoSynapseActE49:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.113 (SI time) duration=0.842 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE50 (Type: expTwoSynapseActE50:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.815 (SI time) duration=0.855 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE51 (Type: expTwoSynapseActE51:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.972 (SI time) duration=2.185 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE52 (Type: expTwoSynapseActE52:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.438 (SI time) duration=1.444 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE53 (Type: expTwoSynapseActE53:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.3 (SI time) duration=2.145 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE54 (Type: expTwoSynapseActE54:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.231 (SI time) duration=1.243 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE55 (Type: expTwoSynapseActE55:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.1160000000000005 (SI time) duration=0.162 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE56 (Type: expTwoSynapseActE56:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.865 (SI time) duration=1.587 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE57 (Type: expTwoSynapseActE57:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.131 (SI time) duration=1.516 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE58 (Type: expTwoSynapseActE58:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.722 (SI time) duration=1.121 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE59 (Type: expTwoSynapseActE59:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.388 (SI time) duration=1.239 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE60 (Type: expTwoSynapseActE60:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.649 (SI time) duration=1.344 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE61 (Type: expTwoSynapseActE61:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.946 (SI time) duration=1.175 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE62 (Type: expTwoSynapseActE62:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.872 (SI time) duration=1.219 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE63 (Type: expTwoSynapseActE63:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.277 (SI time) duration=2.652 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE64 (Type: expTwoSynapseActE64:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.274 (SI time) duration=1.308 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE65 (Type: expTwoSynapseActE65:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.521 (SI time) duration=1.448 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE66 (Type: expTwoSynapseActE66:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.328 (SI time) duration=1.3860000000000001 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE67 (Type: expTwoSynapseActE67:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.131 (SI time) duration=1.022 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE68 (Type: expTwoSynapseActE68:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.548 (SI time) duration=2.07 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE69 (Type: expTwoSynapseActE69:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.127 (SI time) duration=1.0190000000000001 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE70 (Type: expTwoSynapseActE70:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.253 (SI time) duration=1.3820000000000001 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE71 (Type: expTwoSynapseActE71:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.623 (SI time) duration=1.3940000000000001 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE72 (Type: expTwoSynapseActE72:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.54 (SI time) duration=1.6400000000000001 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE73 (Type: expTwoSynapseActE73:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.9430000000000005 (SI time) duration=1.0050000000000001 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE74 (Type: expTwoSynapseActE74:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.734 (SI time) duration=1.935 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE75 (Type: expTwoSynapseActE75:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.406 (SI time) duration=1.538 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE76 (Type: expTwoSynapseActE76:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.889 (SI time) duration=0.37 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE77 (Type: expTwoSynapseActE77:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.495 (SI time) duration=1.083 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE78 (Type: expTwoSynapseActE78:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.586 (SI time) duration=0.249 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE79 (Type: expTwoSynapseActE79:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.486 (SI time) duration=0.246 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE80 (Type: expTwoSynapseActE80:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.224 (SI time) duration=1.114 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE81 (Type: expTwoSynapseActE81:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.891 (SI time) duration=0.626 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE82 (Type: expTwoSynapseActE82:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.667 (SI time) duration=0.317 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE83 (Type: expTwoSynapseActE83:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.46 (SI time) duration=0.018000000000000002 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE84 (Type: expTwoSynapseActE84:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.314 (SI time) duration=0.085 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE85 (Type: expTwoSynapseActE85:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.588 (SI time) duration=0.444 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE86 (Type: expTwoSynapseActE86:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.674 (SI time) duration=0.401 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE87 (Type: expTwoSynapseActE87:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=3.738 (SI time) duration=1.716 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE88 (Type: expTwoSynapseActE88:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.005 (SI time) duration=1.9140000000000001 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE89 (Type: expTwoSynapseActE89:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.771 (SI time) duration=0.667 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE90 (Type: expTwoSynapseActE90:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.413 (SI time) duration=0.79 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE91 (Type: expTwoSynapseActE91:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.324 (SI time) duration=0.873 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE92 (Type: expTwoSynapseActE92:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=3.5300000000000002 (SI time) duration=1.889 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE93 (Type: expTwoSynapseActE93:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.6930000000000005 (SI time) duration=1.016 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE94 (Type: expTwoSynapseActE94:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.274 (SI time) duration=1.163 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE95 (Type: expTwoSynapseActE95:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.187 (SI time) duration=0.597 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE96 (Type: expTwoSynapseActE96:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.9830000000000005 (SI time) duration=1.407 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE97 (Type: expTwoSynapseActE97:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.256 (SI time) duration=1.548 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE98 (Type: expTwoSynapseActE98:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=4.718 (SI time) duration=1.41 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    expTwoSynapseActE99 (Type: expTwoSynapseActE99:  tauRise=0.001 (SI time) tauDecay=0.011 (SI time) delay=5.148 (SI time) duration=1.161 (SI time) peakTime=0.002637684800078208 (SI time) waveformFactor=1.3980797767311548 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    ampsyn (Type: expTwoSynapse:  tauRise=0.001 (SI time) tauDecay=0.005 (SI time) peakTime=0.002011797390542625 (SI time) waveformFactor=1.8691859765265255 (dimensionless) gbase=5.0E-10 (SI conductance) erev=0.0 (SI voltage))
    bcsyn (Type: expTwoSynapse:  tauRise=1.3000000000000002E-4 (SI time) tauDecay=0.011 (SI time) peakTime=5.83855200082304E-4 (SI time) waveformFactor=1.0671230800079607 (dimensionless) gbase=5.0E-10 (SI conductance) erev=-0.07 (SI voltage))
    poissonFirinSynB (Type: poissonFiringSynapse:  averageRate=1.0 (SI per_time) averageIsi=1.0 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    poissonFiringSyn (Type: poissonFiringSynapse:  averageRate=1.0 (SI per_time) averageIsi=1.0 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE0 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE1 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE2 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE3 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE4 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE5 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE6 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE7 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE8 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE9 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE10 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE11 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE12 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE13 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE14 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE15 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE16 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE17 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE18 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE19 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE20 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE21 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE22 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE23 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE24 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE25 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE26 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE27 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE28 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE29 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE30 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE31 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE32 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE33 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE34 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE35 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE36 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE37 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE38 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE39 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE40 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE41 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE42 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE43 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE44 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE45 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE46 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE47 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE48 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE49 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE50 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE51 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE52 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE53 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE54 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE55 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE56 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE57 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE58 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE59 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE60 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE61 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE62 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE63 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE64 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE65 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE66 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE67 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE68 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE69 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE70 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE71 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE72 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE73 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE74 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE75 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE76 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE77 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE78 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE79 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE80 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE81 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE82 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE83 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE84 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE85 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE86 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE87 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE88 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE89 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE90 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE91 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE92 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE93 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE94 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE95 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE96 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE97 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE98 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    PoissonFiringSynAE99 (Type: poissonFiringSynapse:  averageRate=5.0 (SI per_time) averageIsi=0.2 (SI time) SMALL_TIME=1.0000000000000002E-12 (SI time))
    CA1mine1150erev70 (Type: networkWithTemperature:  temperature=279.45 (SI temperature))
    Sim_CA1mine1150erev70 (Type: Simulation:  length=10.0 (SI time) step=1.0E-4 (SI time))


    This NEURON file has been generated by org.neuroml.export (see https://github.com/NeuroML/org.neuroml.export)
         org.neuroml.export  v1.7.1
         org.neuroml.model   v1.7.1
         jLEMS               v0.10.3

'''

import neuron

import time
import datetime
import sys

import hashlib
h = neuron.h
h.load_file("nrngui.hoc")

h("objref p")
h("p = new PythonObject()")

class NeuronSimulation():

    def __init__(self, tstop, dt, seed=4362):

        print("\n    Starting simulation in NEURON of %sms generated from NeuroML2 model...\n"%tstop)

        self.setup_start = time.time()
        self.seed = seed
        self.randoms = []
        self.next_global_id = 0  # Used in Random123 classes for elements using random(), etc. 

        self.next_spiking_input_id = 0  # Used in Random123 classes for elements using random(), etc. 

        '''
        Adding simulation Component(id=Sim_CA1mine1150erev70 type=Simulation) of network/component: CA1mine1150erev70 (Type: networkWithTemperature:  temperature=279.45 (SI temperature))
        
        '''

        # Temperature used for network: 279.45 K
        h.celsius = 279.45 - 273.15

        # ######################   Population: BasketCells
        print("Population BasketCells contains 1 instance(s) of component: CA1_mine of type: cell")

        h.load_file("CA1_mine.hoc")
        a_BasketCells = []
        h("{ n_BasketCells = 1 }")
        h("objectvar a_BasketCells[n_BasketCells]")
        for i in range(int(h.n_BasketCells)):
            h("a_BasketCells[%i] = new CA1_mine()"%i)
            h("access a_BasketCells[%i].soma_0"%i)

            self.next_global_id+=1

        h("{ a_BasketCells[0].position(0.0, 0.0, 0.0) }")

        h("proc initialiseV_BasketCells() { for i = 0, n_BasketCells-1 { a_BasketCells[i].set_initial_v() } }")
        h("objref fih_BasketCells")
        h('{fih_BasketCells = new FInitializeHandler(0, "initialiseV_BasketCells()")}')

        h("proc initialiseIons_BasketCells() { for i = 0, n_BasketCells-1 { a_BasketCells[i].set_initial_ion_properties() } }")
        h("objref fih_ion_BasketCells")
        h('{fih_ion_BasketCells = new FInitializeHandler(1, "initialiseIons_BasketCells()")}')

        print("Processing 101 input lists")

        # ######################   Input List: poissonFirinSynB_input
        # Adding single input: Component(id=0 type=input)
        h("objref poissonFirinSynB_input_0")
        h("a_BasketCells[0].user5_13 { poissonFirinSynB_input_0 = new poissonFirinSynB(0.7267864) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_0 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",0, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_0.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=1 type=input)
        h("objref poissonFirinSynB_input_1")
        h("a_BasketCells[0].user5_21 { poissonFirinSynB_input_1 = new poissonFirinSynB(0.44759455) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_1 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",1, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_1.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=2 type=input)
        h("objref poissonFirinSynB_input_2")
        h("a_BasketCells[0].user5_10 { poissonFirinSynB_input_2 = new poissonFirinSynB(0.8192627) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_2 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",2, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_2.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=3 type=input)
        h("objref poissonFirinSynB_input_3")
        h("a_BasketCells[0].user5_9 { poissonFirinSynB_input_3 = new poissonFirinSynB(0.9517972) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_3 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",3, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_3.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=4 type=input)
        h("objref poissonFirinSynB_input_4")
        h("a_BasketCells[0].user5_5 { poissonFirinSynB_input_4 = new poissonFirinSynB(0.9111479) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_4 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",4, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_4.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=5 type=input)
        h("objref poissonFirinSynB_input_5")
        h("a_BasketCells[0].user5_6 { poissonFirinSynB_input_5 = new poissonFirinSynB(0.9240925) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_5 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",5, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_5.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=6 type=input)
        h("objref poissonFirinSynB_input_6")
        h("a_BasketCells[0].user5_22 { poissonFirinSynB_input_6 = new poissonFirinSynB(0.18801384) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_6 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",6, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_6.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=7 type=input)
        h("objref poissonFirinSynB_input_7")
        h("a_BasketCells[0].user5_7 { poissonFirinSynB_input_7 = new poissonFirinSynB(0.2731957) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_7 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",7, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_7.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=8 type=input)
        h("objref poissonFirinSynB_input_8")
        h("a_BasketCells[0].user5_48 { poissonFirinSynB_input_8 = new poissonFirinSynB(0.9975044) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_8 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",8, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_8.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=9 type=input)
        h("objref poissonFirinSynB_input_9")
        h("a_BasketCells[0].user5_22 { poissonFirinSynB_input_9 = new poissonFirinSynB(0.85468054) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_9 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",9, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_9.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=10 type=input)
        h("objref poissonFirinSynB_input_10")
        h("a_BasketCells[0].user5_39 { poissonFirinSynB_input_10 = new poissonFirinSynB(0.884114) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_10 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",10, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_10.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=11 type=input)
        h("objref poissonFirinSynB_input_11")
        h("a_BasketCells[0].user5_12 { poissonFirinSynB_input_11 = new poissonFirinSynB(0.43000618) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_11 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",11, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_11.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=12 type=input)
        h("objref poissonFirinSynB_input_12")
        h("a_BasketCells[0].user5_45 { poissonFirinSynB_input_12 = new poissonFirinSynB(0.40557334) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_12 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",12, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_12.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=13 type=input)
        h("objref poissonFirinSynB_input_13")
        h("a_BasketCells[0].user5_23 { poissonFirinSynB_input_13 = new poissonFirinSynB(0.03902022) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_13 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",13, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_13.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=14 type=input)
        h("objref poissonFirinSynB_input_14")
        h("a_BasketCells[0].user5_27 { poissonFirinSynB_input_14 = new poissonFirinSynB(0.99281555) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_14 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",14, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_14.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=15 type=input)
        h("objref poissonFirinSynB_input_15")
        h("a_BasketCells[0].user5_32 { poissonFirinSynB_input_15 = new poissonFirinSynB(0.7462421) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_15 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",15, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_15.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=16 type=input)
        h("objref poissonFirinSynB_input_16")
        h("a_BasketCells[0].user5_21 { poissonFirinSynB_input_16 = new poissonFirinSynB(0.8126901) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_16 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",16, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_16.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=17 type=input)
        h("objref poissonFirinSynB_input_17")
        h("a_BasketCells[0].user5_25 { poissonFirinSynB_input_17 = new poissonFirinSynB(0.74663013) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_17 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",17, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_17.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=18 type=input)
        h("objref poissonFirinSynB_input_18")
        h("a_BasketCells[0].user5_21 { poissonFirinSynB_input_18 = new poissonFirinSynB(0.8126901) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_18 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",18, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_18.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=19 type=input)
        h("objref poissonFirinSynB_input_19")
        h("a_BasketCells[0].user5_27 { poissonFirinSynB_input_19 = new poissonFirinSynB(0.69384116) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_19 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",19, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_19.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=20 type=input)
        h("objref poissonFirinSynB_input_20")
        h("a_BasketCells[0].user5_9 { poissonFirinSynB_input_20 = new poissonFirinSynB(0.04565336) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_20 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",20, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_20.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=21 type=input)
        h("objref poissonFirinSynB_input_21")
        h("a_BasketCells[0].user5_47 { poissonFirinSynB_input_21 = new poissonFirinSynB(0.004349906) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_21 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",21, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_21.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=22 type=input)
        h("objref poissonFirinSynB_input_22")
        h("a_BasketCells[0].user5_6 { poissonFirinSynB_input_22 = new poissonFirinSynB(0.5157438) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_22 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",22, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_22.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=23 type=input)
        h("objref poissonFirinSynB_input_23")
        h("a_BasketCells[0].user5_21 { poissonFirinSynB_input_23 = new poissonFirinSynB(0.218795) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_23 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",23, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_23.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=24 type=input)
        h("objref poissonFirinSynB_input_24")
        h("a_BasketCells[0].user5_15 { poissonFirinSynB_input_24 = new poissonFirinSynB(0.582915) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_24 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",24, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_24.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=25 type=input)
        h("objref poissonFirinSynB_input_25")
        h("a_BasketCells[0].user5_21 { poissonFirinSynB_input_25 = new poissonFirinSynB(0.9910038) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_25 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",25, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_25.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=26 type=input)
        h("objref poissonFirinSynB_input_26")
        h("a_BasketCells[0].user5_27 { poissonFirinSynB_input_26 = new poissonFirinSynB(0.9026573) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_26 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",26, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_26.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=27 type=input)
        h("objref poissonFirinSynB_input_27")
        h("a_BasketCells[0].user5_48 { poissonFirinSynB_input_27 = new poissonFirinSynB(0.48606488) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_27 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",27, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_27.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=28 type=input)
        h("objref poissonFirinSynB_input_28")
        h("a_BasketCells[0].user5_28 { poissonFirinSynB_input_28 = new poissonFirinSynB(0.98250437) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_28 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",28, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_28.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=29 type=input)
        h("objref poissonFirinSynB_input_29")
        h("a_BasketCells[0].user5_29 { poissonFirinSynB_input_29 = new poissonFirinSynB(0.74648833) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_29 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",29, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_29.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=30 type=input)
        h("objref poissonFirinSynB_input_30")
        h("a_BasketCells[0].user5_13 { poissonFirinSynB_input_30 = new poissonFirinSynB(0.8147709) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_30 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",30, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_30.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=31 type=input)
        h("objref poissonFirinSynB_input_31")
        h("a_BasketCells[0].user5_9 { poissonFirinSynB_input_31 = new poissonFirinSynB(0.33010885) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_31 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",31, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_31.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=32 type=input)
        h("objref poissonFirinSynB_input_32")
        h("a_BasketCells[0].user5_26 { poissonFirinSynB_input_32 = new poissonFirinSynB(0.9965982) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_32 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",32, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_32.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=33 type=input)
        h("objref poissonFirinSynB_input_33")
        h("a_BasketCells[0].user5_22 { poissonFirinSynB_input_33 = new poissonFirinSynB(0.18801384) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_33 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",33, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_33.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=34 type=input)
        h("objref poissonFirinSynB_input_34")
        h("a_BasketCells[0].user5_41 { poissonFirinSynB_input_34 = new poissonFirinSynB(0.04120221) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_34 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",34, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_34.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=35 type=input)
        h("objref poissonFirinSynB_input_35")
        h("a_BasketCells[0].user5_26 { poissonFirinSynB_input_35 = new poissonFirinSynB(0.3643984) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_35 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",35, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_35.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=36 type=input)
        h("objref poissonFirinSynB_input_36")
        h("a_BasketCells[0].user5_21 { poissonFirinSynB_input_36 = new poissonFirinSynB(0.9910038) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_36 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",36, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_36.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=37 type=input)
        h("objref poissonFirinSynB_input_37")
        h("a_BasketCells[0].user5_11 { poissonFirinSynB_input_37 = new poissonFirinSynB(0.5) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_37 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",37, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_37.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=38 type=input)
        h("objref poissonFirinSynB_input_38")
        h("a_BasketCells[0].user5_22 { poissonFirinSynB_input_38 = new poissonFirinSynB(0.18801384) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_38 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",38, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_38.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=39 type=input)
        h("objref poissonFirinSynB_input_39")
        h("a_BasketCells[0].user5_27 { poissonFirinSynB_input_39 = new poissonFirinSynB(0.034229517) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_39 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",39, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_39.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=40 type=input)
        h("objref poissonFirinSynB_input_40")
        h("a_BasketCells[0].user5_47 { poissonFirinSynB_input_40 = new poissonFirinSynB(0.6480869) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_40 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",40, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_40.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=41 type=input)
        h("objref poissonFirinSynB_input_41")
        h("a_BasketCells[0].user5_0 { poissonFirinSynB_input_41 = new poissonFirinSynB(0.9163588) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_41 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",41, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_41.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=42 type=input)
        h("objref poissonFirinSynB_input_42")
        h("a_BasketCells[0].user5_32 { poissonFirinSynB_input_42 = new poissonFirinSynB(0.2970902) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_42 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",42, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_42.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=43 type=input)
        h("objref poissonFirinSynB_input_43")
        h("a_BasketCells[0].user5_18 { poissonFirinSynB_input_43 = new poissonFirinSynB(0.24174604) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_43 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",43, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_43.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=44 type=input)
        h("objref poissonFirinSynB_input_44")
        h("a_BasketCells[0].user5_9 { poissonFirinSynB_input_44 = new poissonFirinSynB(0.33010885) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_44 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",44, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_44.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=45 type=input)
        h("objref poissonFirinSynB_input_45")
        h("a_BasketCells[0].user5_35 { poissonFirinSynB_input_45 = new poissonFirinSynB(0.9984514) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_45 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",45, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_45.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=46 type=input)
        h("objref poissonFirinSynB_input_46")
        h("a_BasketCells[0].user5_34 { poissonFirinSynB_input_46 = new poissonFirinSynB(0.37291327) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_46 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",46, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_46.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=47 type=input)
        h("objref poissonFirinSynB_input_47")
        h("a_BasketCells[0].user5_23 { poissonFirinSynB_input_47 = new poissonFirinSynB(0.03902022) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_47 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",47, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_47.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=48 type=input)
        h("objref poissonFirinSynB_input_48")
        h("a_BasketCells[0].user5_8 { poissonFirinSynB_input_48 = new poissonFirinSynB(0.95798194) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_48 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",48, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_48.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # Adding single input: Component(id=49 type=input)
        h("objref poissonFirinSynB_input_49")
        h("a_BasketCells[0].user5_25 { poissonFirinSynB_input_49 = new poissonFirinSynB(0.031517748) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on poissonFirinSynB_input_49 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"poissonFirinSynB_input",49, self.seed)
        rand.negexp(1)
        h.poissonFirinSynB_input_49.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE0_input
        # Adding single input: Component(id=0 type=input)
        h("objref PoissonFiringSynAE0_input_0")
        h("a_BasketCells[0].user5_13 { PoissonFiringSynAE0_input_0 = new PoissonFiringSynAE0(0.7267864) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE0_input_0 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE0_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE0_input_0.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE1_input
        # Adding single input: Component(id=1 type=input)
        h("objref PoissonFiringSynAE1_input_1")
        h("a_BasketCells[0].user5_12 { PoissonFiringSynAE1_input_1 = new PoissonFiringSynAE1(0.43000618) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE1_input_1 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE1_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE1_input_1.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE2_input
        # Adding single input: Component(id=2 type=input)
        h("objref PoissonFiringSynAE2_input_2")
        h("a_BasketCells[0].user5_15 { PoissonFiringSynAE2_input_2 = new PoissonFiringSynAE2(0.79415596) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE2_input_2 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE2_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE2_input_2.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE3_input
        # Adding single input: Component(id=3 type=input)
        h("objref PoissonFiringSynAE3_input_3")
        h("a_BasketCells[0].user5_23 { PoissonFiringSynAE3_input_3 = new PoissonFiringSynAE3(0.03902022) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE3_input_3 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE3_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE3_input_3.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE4_input
        # Adding single input: Component(id=4 type=input)
        h("objref PoissonFiringSynAE4_input_4")
        h("a_BasketCells[0].user5_33 { PoissonFiringSynAE4_input_4 = new PoissonFiringSynAE4(0.13262759) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE4_input_4 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE4_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE4_input_4.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE5_input
        # Adding single input: Component(id=5 type=input)
        h("objref PoissonFiringSynAE5_input_5")
        h("a_BasketCells[0].user5_40 { PoissonFiringSynAE5_input_5 = new PoissonFiringSynAE5(0.12846574) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE5_input_5 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE5_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE5_input_5.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE6_input
        # Adding single input: Component(id=6 type=input)
        h("objref PoissonFiringSynAE6_input_6")
        h("a_BasketCells[0].user5_32 { PoissonFiringSynAE6_input_6 = new PoissonFiringSynAE6(0.15089583) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE6_input_6 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE6_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE6_input_6.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE7_input
        # Adding single input: Component(id=7 type=input)
        h("objref PoissonFiringSynAE7_input_7")
        h("a_BasketCells[0].user5_12 { PoissonFiringSynAE7_input_7 = new PoissonFiringSynAE7(0.75448436) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE7_input_7 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE7_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE7_input_7.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE8_input
        # Adding single input: Component(id=8 type=input)
        h("objref PoissonFiringSynAE8_input_8")
        h("a_BasketCells[0].user5_31 { PoissonFiringSynAE8_input_8 = new PoissonFiringSynAE8(0.67277765) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE8_input_8 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE8_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE8_input_8.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE9_input
        # Adding single input: Component(id=9 type=input)
        h("objref PoissonFiringSynAE9_input_9")
        h("a_BasketCells[0].user5_39 { PoissonFiringSynAE9_input_9 = new PoissonFiringSynAE9(0.036315054) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE9_input_9 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE9_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE9_input_9.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE10_input
        # Adding single input: Component(id=10 type=input)
        h("objref PoissonFiringSynAE10_input_10")
        h("a_BasketCells[0].user5_21 { PoissonFiringSynAE10_input_10 = new PoissonFiringSynAE10(0.5660388) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE10_input_10 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE10_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE10_input_10.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE11_input
        # Adding single input: Component(id=11 type=input)
        h("objref PoissonFiringSynAE11_input_11")
        h("a_BasketCells[0].user5_45 { PoissonFiringSynAE11_input_11 = new PoissonFiringSynAE11(0.8631379) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE11_input_11 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE11_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE11_input_11.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE12_input
        # Adding single input: Component(id=12 type=input)
        h("objref PoissonFiringSynAE12_input_12")
        h("a_BasketCells[0].user5_6 { PoissonFiringSynAE12_input_12 = new PoissonFiringSynAE12(0.9240925) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE12_input_12 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE12_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE12_input_12.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE13_input
        # Adding single input: Component(id=13 type=input)
        h("objref PoissonFiringSynAE13_input_13")
        h("a_BasketCells[0].user5_38 { PoissonFiringSynAE13_input_13 = new PoissonFiringSynAE13(0.90017307) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE13_input_13 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE13_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE13_input_13.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE14_input
        # Adding single input: Component(id=14 type=input)
        h("objref PoissonFiringSynAE14_input_14")
        h("a_BasketCells[0].user5_9 { PoissonFiringSynAE14_input_14 = new PoissonFiringSynAE14(0.33010885) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE14_input_14 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE14_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE14_input_14.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE15_input
        # Adding single input: Component(id=15 type=input)
        h("objref PoissonFiringSynAE15_input_15")
        h("a_BasketCells[0].user5_20 { PoissonFiringSynAE15_input_15 = new PoissonFiringSynAE15(0.18791173) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE15_input_15 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE15_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE15_input_15.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE16_input
        # Adding single input: Component(id=16 type=input)
        h("objref PoissonFiringSynAE16_input_16")
        h("a_BasketCells[0].user5_24 { PoissonFiringSynAE16_input_16 = new PoissonFiringSynAE16(0.047213685) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE16_input_16 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE16_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE16_input_16.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE17_input
        # Adding single input: Component(id=17 type=input)
        h("objref PoissonFiringSynAE17_input_17")
        h("a_BasketCells[0].user5_13 { PoissonFiringSynAE17_input_17 = new PoissonFiringSynAE17(0.96179694) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE17_input_17 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE17_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE17_input_17.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE18_input
        # Adding single input: Component(id=18 type=input)
        h("objref PoissonFiringSynAE18_input_18")
        h("a_BasketCells[0].user5_22 { PoissonFiringSynAE18_input_18 = new PoissonFiringSynAE18(0.18801384) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE18_input_18 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE18_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE18_input_18.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE19_input
        # Adding single input: Component(id=19 type=input)
        h("objref PoissonFiringSynAE19_input_19")
        h("a_BasketCells[0].user5_13 { PoissonFiringSynAE19_input_19 = new PoissonFiringSynAE19(0.96179694) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE19_input_19 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE19_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE19_input_19.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE20_input
        # Adding single input: Component(id=20 type=input)
        h("objref PoissonFiringSynAE20_input_20")
        h("a_BasketCells[0].user5_13 { PoissonFiringSynAE20_input_20 = new PoissonFiringSynAE20(0.88613766) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE20_input_20 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE20_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE20_input_20.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE21_input
        # Adding single input: Component(id=21 type=input)
        h("objref PoissonFiringSynAE21_input_21")
        h("a_BasketCells[0].user5_27 { PoissonFiringSynAE21_input_21 = new PoissonFiringSynAE21(0.034229517) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE21_input_21 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE21_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE21_input_21.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE22_input
        # Adding single input: Component(id=22 type=input)
        h("objref PoissonFiringSynAE22_input_22")
        h("a_BasketCells[0].user5_30 { PoissonFiringSynAE22_input_22 = new PoissonFiringSynAE22(0.19292401) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE22_input_22 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE22_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE22_input_22.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE23_input
        # Adding single input: Component(id=23 type=input)
        h("objref PoissonFiringSynAE23_input_23")
        h("a_BasketCells[0].user5_3 { PoissonFiringSynAE23_input_23 = new PoissonFiringSynAE23(0.8833062) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE23_input_23 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE23_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE23_input_23.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE24_input
        # Adding single input: Component(id=24 type=input)
        h("objref PoissonFiringSynAE24_input_24")
        h("a_BasketCells[0].user5_23 { PoissonFiringSynAE24_input_24 = new PoissonFiringSynAE24(0.9805661) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE24_input_24 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE24_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE24_input_24.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE25_input
        # Adding single input: Component(id=25 type=input)
        h("objref PoissonFiringSynAE25_input_25")
        h("a_BasketCells[0].user5_47 { PoissonFiringSynAE25_input_25 = new PoissonFiringSynAE25(0.14707392) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE25_input_25 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE25_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE25_input_25.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE26_input
        # Adding single input: Component(id=26 type=input)
        h("objref PoissonFiringSynAE26_input_26")
        h("a_BasketCells[0].user5_14 { PoissonFiringSynAE26_input_26 = new PoissonFiringSynAE26(0.36092943) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE26_input_26 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE26_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE26_input_26.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE27_input
        # Adding single input: Component(id=27 type=input)
        h("objref PoissonFiringSynAE27_input_27")
        h("a_BasketCells[0].user5_29 { PoissonFiringSynAE27_input_27 = new PoissonFiringSynAE27(0.87395877) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE27_input_27 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE27_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE27_input_27.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE28_input
        # Adding single input: Component(id=28 type=input)
        h("objref PoissonFiringSynAE28_input_28")
        h("a_BasketCells[0].user5_39 { PoissonFiringSynAE28_input_28 = new PoissonFiringSynAE28(0.036315054) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE28_input_28 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE28_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE28_input_28.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE29_input
        # Adding single input: Component(id=29 type=input)
        h("objref PoissonFiringSynAE29_input_29")
        h("a_BasketCells[0].user5_23 { PoissonFiringSynAE29_input_29 = new PoissonFiringSynAE29(0.31043896) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE29_input_29 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE29_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE29_input_29.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE30_input
        # Adding single input: Component(id=30 type=input)
        h("objref PoissonFiringSynAE30_input_30")
        h("a_BasketCells[0].user5_24 { PoissonFiringSynAE30_input_30 = new PoissonFiringSynAE30(0.7326512) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE30_input_30 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE30_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE30_input_30.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE31_input
        # Adding single input: Component(id=31 type=input)
        h("objref PoissonFiringSynAE31_input_31")
        h("a_BasketCells[0].user5_48 { PoissonFiringSynAE31_input_31 = new PoissonFiringSynAE31(0.48606488) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE31_input_31 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE31_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE31_input_31.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE32_input
        # Adding single input: Component(id=32 type=input)
        h("objref PoissonFiringSynAE32_input_32")
        h("a_BasketCells[0].user5_14 { PoissonFiringSynAE32_input_32 = new PoissonFiringSynAE32(0.75341326) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE32_input_32 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE32_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE32_input_32.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE33_input
        # Adding single input: Component(id=33 type=input)
        h("objref PoissonFiringSynAE33_input_33")
        h("a_BasketCells[0].user5_25 { PoissonFiringSynAE33_input_33 = new PoissonFiringSynAE33(0.9860703) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE33_input_33 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE33_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE33_input_33.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE34_input
        # Adding single input: Component(id=34 type=input)
        h("objref PoissonFiringSynAE34_input_34")
        h("a_BasketCells[0].user5_21 { PoissonFiringSynAE34_input_34 = new PoissonFiringSynAE34(0.019518327) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE34_input_34 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE34_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE34_input_34.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE35_input
        # Adding single input: Component(id=35 type=input)
        h("objref PoissonFiringSynAE35_input_35")
        h("a_BasketCells[0].user5_27 { PoissonFiringSynAE35_input_35 = new PoissonFiringSynAE35(0.034229517) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE35_input_35 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE35_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE35_input_35.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE36_input
        # Adding single input: Component(id=36 type=input)
        h("objref PoissonFiringSynAE36_input_36")
        h("a_BasketCells[0].user5_9 { PoissonFiringSynAE36_input_36 = new PoissonFiringSynAE36(0.6485403) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE36_input_36 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE36_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE36_input_36.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE37_input
        # Adding single input: Component(id=37 type=input)
        h("objref PoissonFiringSynAE37_input_37")
        h("a_BasketCells[0].user5_0 { PoissonFiringSynAE37_input_37 = new PoissonFiringSynAE37(0.7013987) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE37_input_37 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE37_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE37_input_37.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE38_input
        # Adding single input: Component(id=38 type=input)
        h("objref PoissonFiringSynAE38_input_38")
        h("a_BasketCells[0].user5_26 { PoissonFiringSynAE38_input_38 = new PoissonFiringSynAE38(0.5109568) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE38_input_38 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE38_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE38_input_38.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE39_input
        # Adding single input: Component(id=39 type=input)
        h("objref PoissonFiringSynAE39_input_39")
        h("a_BasketCells[0].user5_26 { PoissonFiringSynAE39_input_39 = new PoissonFiringSynAE39(0.9965982) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE39_input_39 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE39_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE39_input_39.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE40_input
        # Adding single input: Component(id=40 type=input)
        h("objref PoissonFiringSynAE40_input_40")
        h("a_BasketCells[0].user5_0 { PoissonFiringSynAE40_input_40 = new PoissonFiringSynAE40(0.99035823) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE40_input_40 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE40_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE40_input_40.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE41_input
        # Adding single input: Component(id=41 type=input)
        h("objref PoissonFiringSynAE41_input_41")
        h("a_BasketCells[0].user5_30 { PoissonFiringSynAE41_input_41 = new PoissonFiringSynAE41(0.005184143) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE41_input_41 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE41_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE41_input_41.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE42_input
        # Adding single input: Component(id=42 type=input)
        h("objref PoissonFiringSynAE42_input_42")
        h("a_BasketCells[0].user5_28 { PoissonFiringSynAE42_input_42 = new PoissonFiringSynAE42(0.6537834) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE42_input_42 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE42_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE42_input_42.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE43_input
        # Adding single input: Component(id=43 type=input)
        h("objref PoissonFiringSynAE43_input_43")
        h("a_BasketCells[0].user5_24 { PoissonFiringSynAE43_input_43 = new PoissonFiringSynAE43(0.7326512) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE43_input_43 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE43_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE43_input_43.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE44_input
        # Adding single input: Component(id=44 type=input)
        h("objref PoissonFiringSynAE44_input_44")
        h("a_BasketCells[0].user5_28 { PoissonFiringSynAE44_input_44 = new PoissonFiringSynAE44(0.6537834) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE44_input_44 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE44_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE44_input_44.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE45_input
        # Adding single input: Component(id=45 type=input)
        h("objref PoissonFiringSynAE45_input_45")
        h("a_BasketCells[0].user5_16 { PoissonFiringSynAE45_input_45 = new PoissonFiringSynAE45(0.7827507) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE45_input_45 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE45_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE45_input_45.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE46_input
        # Adding single input: Component(id=46 type=input)
        h("objref PoissonFiringSynAE46_input_46")
        h("a_BasketCells[0].user5_25 { PoissonFiringSynAE46_input_46 = new PoissonFiringSynAE46(0.87898636) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE46_input_46 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE46_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE46_input_46.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE47_input
        # Adding single input: Component(id=47 type=input)
        h("objref PoissonFiringSynAE47_input_47")
        h("a_BasketCells[0].user5_13 { PoissonFiringSynAE47_input_47 = new PoissonFiringSynAE47(0.15465891) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE47_input_47 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE47_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE47_input_47.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE48_input
        # Adding single input: Component(id=48 type=input)
        h("objref PoissonFiringSynAE48_input_48")
        h("a_BasketCells[0].user5_18 { PoissonFiringSynAE48_input_48 = new PoissonFiringSynAE48(0.998631) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE48_input_48 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE48_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE48_input_48.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE49_input
        # Adding single input: Component(id=49 type=input)
        h("objref PoissonFiringSynAE49_input_49")
        h("a_BasketCells[0].user5_29 { PoissonFiringSynAE49_input_49 = new PoissonFiringSynAE49(0.98762715) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE49_input_49 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE49_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE49_input_49.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE50_input
        # Adding single input: Component(id=50 type=input)
        h("objref PoissonFiringSynAE50_input_50")
        h("a_BasketCells[0].user5_7 { PoissonFiringSynAE50_input_50 = new PoissonFiringSynAE50(0.2731957) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE50_input_50 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE50_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE50_input_50.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE51_input
        # Adding single input: Component(id=51 type=input)
        h("objref PoissonFiringSynAE51_input_51")
        h("a_BasketCells[0].user5_20 { PoissonFiringSynAE51_input_51 = new PoissonFiringSynAE51(0.2961231) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE51_input_51 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE51_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE51_input_51.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE52_input
        # Adding single input: Component(id=52 type=input)
        h("objref PoissonFiringSynAE52_input_52")
        h("a_BasketCells[0].user5_9 { PoissonFiringSynAE52_input_52 = new PoissonFiringSynAE52(0.6485403) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE52_input_52 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE52_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE52_input_52.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE53_input
        # Adding single input: Component(id=53 type=input)
        h("objref PoissonFiringSynAE53_input_53")
        h("a_BasketCells[0].user5_6 { PoissonFiringSynAE53_input_53 = new PoissonFiringSynAE53(0.9240925) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE53_input_53 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE53_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE53_input_53.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE54_input
        # Adding single input: Component(id=54 type=input)
        h("objref PoissonFiringSynAE54_input_54")
        h("a_BasketCells[0].user5_36 { PoissonFiringSynAE54_input_54 = new PoissonFiringSynAE54(0.07538637) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE54_input_54 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE54_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE54_input_54.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE55_input
        # Adding single input: Component(id=55 type=input)
        h("objref PoissonFiringSynAE55_input_55")
        h("a_BasketCells[0].user5_7 { PoissonFiringSynAE55_input_55 = new PoissonFiringSynAE55(0.2731957) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE55_input_55 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE55_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE55_input_55.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE56_input
        # Adding single input: Component(id=56 type=input)
        h("objref PoissonFiringSynAE56_input_56")
        h("a_BasketCells[0].user5_27 { PoissonFiringSynAE56_input_56 = new PoissonFiringSynAE56(0.69384116) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE56_input_56 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE56_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE56_input_56.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE57_input
        # Adding single input: Component(id=57 type=input)
        h("objref PoissonFiringSynAE57_input_57")
        h("a_BasketCells[0].user5_35 { PoissonFiringSynAE57_input_57 = new PoissonFiringSynAE57(0.40080276) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE57_input_57 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE57_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE57_input_57.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE58_input
        # Adding single input: Component(id=58 type=input)
        h("objref PoissonFiringSynAE58_input_58")
        h("a_BasketCells[0].user5_28 { PoissonFiringSynAE58_input_58 = new PoissonFiringSynAE58(0.8520445) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE58_input_58 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE58_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE58_input_58.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE59_input
        # Adding single input: Component(id=59 type=input)
        h("objref PoissonFiringSynAE59_input_59")
        h("a_BasketCells[0].user5_18 { PoissonFiringSynAE59_input_59 = new PoissonFiringSynAE59(0.24174604) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE59_input_59 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE59_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE59_input_59.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE60_input
        # Adding single input: Component(id=60 type=input)
        h("objref PoissonFiringSynAE60_input_60")
        h("a_BasketCells[0].user5_24 { PoissonFiringSynAE60_input_60 = new PoissonFiringSynAE60(0.7326512) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE60_input_60 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE60_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE60_input_60.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE61_input
        # Adding single input: Component(id=61 type=input)
        h("objref PoissonFiringSynAE61_input_61")
        h("a_BasketCells[0].user5_8 { PoissonFiringSynAE61_input_61 = new PoissonFiringSynAE61(0.67728347) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE61_input_61 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE61_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE61_input_61.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE62_input
        # Adding single input: Component(id=62 type=input)
        h("objref PoissonFiringSynAE62_input_62")
        h("a_BasketCells[0].user5_14 { PoissonFiringSynAE62_input_62 = new PoissonFiringSynAE62(0.04925032) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE62_input_62 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE62_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE62_input_62.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE63_input
        # Adding single input: Component(id=63 type=input)
        h("objref PoissonFiringSynAE63_input_63")
        h("a_BasketCells[0].user5_37 { PoissonFiringSynAE63_input_63 = new PoissonFiringSynAE63(0.013049889) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE63_input_63 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE63_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE63_input_63.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE64_input
        # Adding single input: Component(id=64 type=input)
        h("objref PoissonFiringSynAE64_input_64")
        h("a_BasketCells[0].user5_6 { PoissonFiringSynAE64_input_64 = new PoissonFiringSynAE64(0.08377944) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE64_input_64 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE64_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE64_input_64.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE65_input
        # Adding single input: Component(id=65 type=input)
        h("objref PoissonFiringSynAE65_input_65")
        h("a_BasketCells[0].user5_32 { PoissonFiringSynAE65_input_65 = new PoissonFiringSynAE65(0.9983327) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE65_input_65 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE65_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE65_input_65.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE66_input
        # Adding single input: Component(id=66 type=input)
        h("objref PoissonFiringSynAE66_input_66")
        h("a_BasketCells[0].user5_25 { PoissonFiringSynAE66_input_66 = new PoissonFiringSynAE66(0.28951913) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE66_input_66 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE66_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE66_input_66.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE67_input
        # Adding single input: Component(id=67 type=input)
        h("objref PoissonFiringSynAE67_input_67")
        h("a_BasketCells[0].user5_18 { PoissonFiringSynAE67_input_67 = new PoissonFiringSynAE67(0.45911106) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE67_input_67 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE67_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE67_input_67.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE68_input
        # Adding single input: Component(id=68 type=input)
        h("objref PoissonFiringSynAE68_input_68")
        h("a_BasketCells[0].user5_48 { PoissonFiringSynAE68_input_68 = new PoissonFiringSynAE68(0.06837141) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE68_input_68 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE68_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE68_input_68.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE69_input
        # Adding single input: Component(id=69 type=input)
        h("objref PoissonFiringSynAE69_input_69")
        h("a_BasketCells[0].user5_26 { PoissonFiringSynAE69_input_69 = new PoissonFiringSynAE69(0.5109568) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE69_input_69 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE69_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE69_input_69.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE70_input
        # Adding single input: Component(id=70 type=input)
        h("objref PoissonFiringSynAE70_input_70")
        h("a_BasketCells[0].user5_24 { PoissonFiringSynAE70_input_70 = new PoissonFiringSynAE70(0.7326512) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE70_input_70 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE70_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE70_input_70.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE71_input
        # Adding single input: Component(id=71 type=input)
        h("objref PoissonFiringSynAE71_input_71")
        h("a_BasketCells[0].user5_25 { PoissonFiringSynAE71_input_71 = new PoissonFiringSynAE71(0.54179215) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE71_input_71 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE71_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE71_input_71.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE72_input
        # Adding single input: Component(id=72 type=input)
        h("objref PoissonFiringSynAE72_input_72")
        h("a_BasketCells[0].user5_16 { PoissonFiringSynAE72_input_72 = new PoissonFiringSynAE72(0.011820729) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE72_input_72 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE72_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE72_input_72.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE73_input
        # Adding single input: Component(id=73 type=input)
        h("objref PoissonFiringSynAE73_input_73")
        h("a_BasketCells[0].user5_12 { PoissonFiringSynAE73_input_73 = new PoissonFiringSynAE73(0.43000618) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE73_input_73 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE73_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE73_input_73.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE74_input
        # Adding single input: Component(id=74 type=input)
        h("objref PoissonFiringSynAE74_input_74")
        h("a_BasketCells[0].user5_32 { PoissonFiringSynAE74_input_74 = new PoissonFiringSynAE74(0.42356652) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE74_input_74 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE74_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE74_input_74.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE75_input
        # Adding single input: Component(id=75 type=input)
        h("objref PoissonFiringSynAE75_input_75")
        h("a_BasketCells[0].user5_5 { PoissonFiringSynAE75_input_75 = new PoissonFiringSynAE75(0.9111479) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE75_input_75 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE75_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE75_input_75.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE76_input
        # Adding single input: Component(id=76 type=input)
        h("objref PoissonFiringSynAE76_input_76")
        h("a_BasketCells[0].user5_23 { PoissonFiringSynAE76_input_76 = new PoissonFiringSynAE76(0.8115494) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE76_input_76 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE76_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE76_input_76.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE77_input
        # Adding single input: Component(id=77 type=input)
        h("objref PoissonFiringSynAE77_input_77")
        h("a_BasketCells[0].user5_23 { PoissonFiringSynAE77_input_77 = new PoissonFiringSynAE77(0.03902022) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE77_input_77 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE77_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE77_input_77.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE78_input
        # Adding single input: Component(id=78 type=input)
        h("objref PoissonFiringSynAE78_input_78")
        h("a_BasketCells[0].user5_24 { PoissonFiringSynAE78_input_78 = new PoissonFiringSynAE78(0.36606273) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE78_input_78 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE78_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE78_input_78.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE79_input
        # Adding single input: Component(id=79 type=input)
        h("objref PoissonFiringSynAE79_input_79")
        h("a_BasketCells[0].user5_23 { PoissonFiringSynAE79_input_79 = new PoissonFiringSynAE79(0.31043896) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE79_input_79 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE79_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE79_input_79.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE80_input
        # Adding single input: Component(id=80 type=input)
        h("objref PoissonFiringSynAE80_input_80")
        h("a_BasketCells[0].user5_26 { PoissonFiringSynAE80_input_80 = new PoissonFiringSynAE80(0.7205314) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE80_input_80 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE80_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE80_input_80.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE81_input
        # Adding single input: Component(id=81 type=input)
        h("objref PoissonFiringSynAE81_input_81")
        h("a_BasketCells[0].user5_36 { PoissonFiringSynAE81_input_81 = new PoissonFiringSynAE81(0.72312725) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE81_input_81 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE81_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE81_input_81.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE82_input
        # Adding single input: Component(id=82 type=input)
        h("objref PoissonFiringSynAE82_input_82")
        h("a_BasketCells[0].user5_28 { PoissonFiringSynAE82_input_82 = new PoissonFiringSynAE82(0.392704) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE82_input_82 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE82_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE82_input_82.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE83_input
        # Adding single input: Component(id=83 type=input)
        h("objref PoissonFiringSynAE83_input_83")
        h("a_BasketCells[0].user5_36 { PoissonFiringSynAE83_input_83 = new PoissonFiringSynAE83(0.15799847) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE83_input_83 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE83_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE83_input_83.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE84_input
        # Adding single input: Component(id=84 type=input)
        h("objref PoissonFiringSynAE84_input_84")
        h("a_BasketCells[0].user5_19 { PoissonFiringSynAE84_input_84 = new PoissonFiringSynAE84(0.3938573) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE84_input_84 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE84_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE84_input_84.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE85_input
        # Adding single input: Component(id=85 type=input)
        h("objref PoissonFiringSynAE85_input_85")
        h("a_BasketCells[0].user5_21 { PoissonFiringSynAE85_input_85 = new PoissonFiringSynAE85(0.5660388) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE85_input_85 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE85_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE85_input_85.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE86_input
        # Adding single input: Component(id=86 type=input)
        h("objref PoissonFiringSynAE86_input_86")
        h("a_BasketCells[0].user5_25 { PoissonFiringSynAE86_input_86 = new PoissonFiringSynAE86(0.87898636) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE86_input_86 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE86_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE86_input_86.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE87_input
        # Adding single input: Component(id=87 type=input)
        h("objref PoissonFiringSynAE87_input_87")
        h("a_BasketCells[0].user5_29 { PoissonFiringSynAE87_input_87 = new PoissonFiringSynAE87(0.87395877) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE87_input_87 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE87_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE87_input_87.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE88_input
        # Adding single input: Component(id=88 type=input)
        h("objref PoissonFiringSynAE88_input_88")
        h("a_BasketCells[0].user5_21 { PoissonFiringSynAE88_input_88 = new PoissonFiringSynAE88(0.218795) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE88_input_88 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE88_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE88_input_88.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE89_input
        # Adding single input: Component(id=89 type=input)
        h("objref PoissonFiringSynAE89_input_89")
        h("a_BasketCells[0].user5_27 { PoissonFiringSynAE89_input_89 = new PoissonFiringSynAE89(0.9026573) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE89_input_89 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE89_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE89_input_89.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE90_input
        # Adding single input: Component(id=90 type=input)
        h("objref PoissonFiringSynAE90_input_90")
        h("a_BasketCells[0].user5_29 { PoissonFiringSynAE90_input_90 = new PoissonFiringSynAE90(0.98762715) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE90_input_90 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE90_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE90_input_90.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE91_input
        # Adding single input: Component(id=91 type=input)
        h("objref PoissonFiringSynAE91_input_91")
        h("a_BasketCells[0].user5_26 { PoissonFiringSynAE91_input_91 = new PoissonFiringSynAE91(0.016826792) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE91_input_91 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE91_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE91_input_91.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE92_input
        # Adding single input: Component(id=92 type=input)
        h("objref PoissonFiringSynAE92_input_92")
        h("a_BasketCells[0].user5_27 { PoissonFiringSynAE92_input_92 = new PoissonFiringSynAE92(0.034229517) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE92_input_92 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE92_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE92_input_92.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE93_input
        # Adding single input: Component(id=93 type=input)
        h("objref PoissonFiringSynAE93_input_93")
        h("a_BasketCells[0].user5_22 { PoissonFiringSynAE93_input_93 = new PoissonFiringSynAE93(0.85468054) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE93_input_93 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE93_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE93_input_93.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE94_input
        # Adding single input: Component(id=94 type=input)
        h("objref PoissonFiringSynAE94_input_94")
        h("a_BasketCells[0].user5_39 { PoissonFiringSynAE94_input_94 = new PoissonFiringSynAE94(0.73645705) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE94_input_94 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE94_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE94_input_94.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE95_input
        # Adding single input: Component(id=95 type=input)
        h("objref PoissonFiringSynAE95_input_95")
        h("a_BasketCells[0].user5_40 { PoissonFiringSynAE95_input_95 = new PoissonFiringSynAE95(0.12846574) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE95_input_95 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE95_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE95_input_95.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE96_input
        # Adding single input: Component(id=96 type=input)
        h("objref PoissonFiringSynAE96_input_96")
        h("a_BasketCells[0].user5_6 { PoissonFiringSynAE96_input_96 = new PoissonFiringSynAE96(0.9240925) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE96_input_96 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE96_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE96_input_96.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE97_input
        # Adding single input: Component(id=97 type=input)
        h("objref PoissonFiringSynAE97_input_97")
        h("a_BasketCells[0].user5_24 { PoissonFiringSynAE97_input_97 = new PoissonFiringSynAE97(0.9694098) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE97_input_97 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE97_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE97_input_97.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE98_input
        # Adding single input: Component(id=98 type=input)
        h("objref PoissonFiringSynAE98_input_98")
        h("a_BasketCells[0].user5_13 { PoissonFiringSynAE98_input_98 = new PoissonFiringSynAE98(0.61168987) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE98_input_98 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE98_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE98_input_98.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        # ######################   Input List: PoissonFiringSynAE99_input
        # Adding single input: Component(id=99 type=input)
        h("objref PoissonFiringSynAE99_input_99")
        h("a_BasketCells[0].user5_38 { PoissonFiringSynAE99_input_99 = new PoissonFiringSynAE99(0.07546174) } ")
        rand = h.Random()
        self.randoms.append(rand)
        #print("Seeding random generator on PoissonFiringSynAE99_input_99 with stim seed %s"%(self.seed))
        self._init_stim_randomizer(rand,"PoissonFiringSynAE99_input",0, self.seed)
        rand.negexp(1)
        h.PoissonFiringSynAE99_input_99.noiseFromRandom(rand)
        self.next_spiking_input_id+=1

        print("Finished processing 101 input lists")

        trec = h.Vector()
        trec.record(h._ref_t)

        h.tstop = tstop

        h.dt = dt

        h.steps_per_ms = 1/h.dt

        # ######################   Display: self.display_display_bc
        self.display_display_bc = h.Graph(0)
        self.display_display_bc.size(0,h.tstop,-80.0,50.0)
        self.display_display_bc.view(0, -80.0, h.tstop, 130.0, 80, 330, 330, 250)
        h.graphList[0].append(self.display_display_bc)
        # Line, plotting: BasketCells/0/CA1_mine/v
        self.display_display_bc.addexpr("a_BasketCells[0].soma_0.v(0.5)", "a_BasketCells[0].soma_0.v(0.5)", 1, 1, 0.8, 0.9, 2)



        # ######################   File to save: time.dat (time)
        # Column: time
        h(' objectvar v_time ')
        h(' { v_time = new Vector() } ')
        h(' { v_time.record(&t) } ')
        h.v_time.resize((h.tstop * h.steps_per_ms) + 1)

        # ######################   File to save: v_CA1mine1150erev70seg_id0.dat (Volts_file_bc)
        # Column: BasketCells/0/CA1_mine/v
        h(' objectvar v_v_0_Volts_file_bc ')
        h(' { v_v_0_Volts_file_bc = new Vector() } ')
        h(' { v_v_0_Volts_file_bc.record(&a_BasketCells[0].soma_0.v(0.5)) } ')
        h.v_v_0_Volts_file_bc.resize((h.tstop * h.steps_per_ms) + 1)

        self.initialized = False

        self.sim_end = -1 # will be overwritten

        setup_end = time.time()
        self.setup_time = setup_end - self.setup_start
        print("Setting up the network to simulate took %f seconds"%(self.setup_time))

        h.nrncontrolmenu()


    def run(self):

        self.initialized = True
        sim_start = time.time()
        print("Running a simulation of %sms (dt = %sms; seed=%s)" % (h.tstop, h.dt, self.seed))

        try:
            h.run()
        except Exception as e:
            print("Exception running NEURON: %s" % (e))
            return


        self.sim_end = time.time()
        self.sim_time = self.sim_end - sim_start
        print("Finished NEURON simulation in %f seconds (%f mins)..."%(self.sim_time, self.sim_time/60.0))

        try:
            self.save_results()
        except Exception as e:
            print("Exception saving results of NEURON simulation: %s" % (e))
            return


    def advance(self):

        if not self.initialized:
            h.finitialize()
            self.initialized = True

        h.fadvance()


    ###############################################################################
    # Hash function to use in generation of random value
    # This is copied from NetPyNE: https://github.com/Neurosim-lab/netpyne/blob/master/netpyne/simFuncs.py
    ###############################################################################
    def _id32 (self,obj): 
        return int(hashlib.md5(obj.encode('utf-8')).hexdigest()[0:8],16)  # convert 8 first chars of md5 hash in base 16 to int


    ###############################################################################
    # Initialize the stim randomizer
    # This is copied from NetPyNE: https://github.com/Neurosim-lab/netpyne/blob/master/netpyne/simFuncs.py
    ###############################################################################
    def _init_stim_randomizer(self,rand, stimType, gid, seed): 
        #print("INIT STIM  %s; %s; %s; %s"%(rand, stimType, gid, seed))
        rand.Random123(self._id32(stimType), gid, seed)


    def save_results(self):

        print("Saving results at t=%s..."%h.t)

        if self.sim_end < 0: self.sim_end = time.time()

        self.display_display_bc.exec_menu("View = plot")

        # ######################   File to save: time.dat (time)
        py_v_time = [ t/1000 for t in h.v_time.to_python() ]  # Convert to Python list for speed...

        f_time_f2 = open('time.dat', 'w')
        num_points = len(py_v_time)  # Simulation may have been stopped before tstop...

        for i in range(num_points):
            f_time_f2.write('%f'% py_v_time[i])  # Save in SI units...
        f_time_f2.close()
        print("Saved data to: time.dat")

        # ######################   File to save: v_CA1mine1150erev70seg_id0.dat (Volts_file_bc)
        py_v_v_0_Volts_file_bc = [ float(x  / 1000.0) for x in h.v_v_0_Volts_file_bc.to_python() ]  # Convert to Python list for speed, variable has dim: voltage

        f_Volts_file_bc_f2 = open('v_CA1mine1150erev70seg_id0.dat', 'w')
        num_points = len(py_v_time)  # Simulation may have been stopped before tstop...

        for i in range(num_points):
            f_Volts_file_bc_f2.write('%e\t%e\t\n' % (py_v_time[i], py_v_v_0_Volts_file_bc[i], ))
        f_Volts_file_bc_f2.close()
        print("Saved data to: v_CA1mine1150erev70seg_id0.dat")

        save_end = time.time()
        save_time = save_end - self.sim_end
        print("Finished saving results in %f seconds"%(save_time))

        print("Done")

if __name__ == '__main__':

    ns = NeuronSimulation(tstop=10000, dt=0.1, seed=4362)

    ns.run()

